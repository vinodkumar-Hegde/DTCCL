import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || "" });

export const extractCaseData = async (fileData: string, mimeType: string) => {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Analyze this clinical case sheet. Extract the following information in a structured JSON format:
    1. Patient History (Chief complaints, HPI, Past history, Family history, Personal history)
    2. Lab Reports (Parameter, Value, Unit, Reference Range as per AIIMS guidelines)
    3. Clinical Notes (Day to day treatment and progress)
    4. Summary (Brief overview of the case)
    5. AI Opinion (Soft-toned opinion on the treatment, suggesting any missed procedures or improvements based on standard protocols)
    6. Flowchart Data (A sequence of steps representing the patient's journey from admission to discharge/outcome)

    IMPORTANT: Anonymize the patient. Remove any names, exact dates of birth, or specific identifiers.
    Use standard medical terminology.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          { text: prompt },
          { inlineData: { data: fileData.split(',')[1] || fileData, mimeType } }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          history: {
            type: Type.OBJECT,
            properties: {
              chief_complaints: { type: Type.ARRAY, items: { type: Type.STRING } },
              history_of_present_illness: { type: Type.STRING },
              past_history: { type: Type.STRING },
              family_history: { type: Type.STRING },
              personal_history: { type: Type.STRING }
            }
          },
          lab_reports: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                parameter: { type: Type.STRING },
                value: { type: Type.STRING },
                unit: { type: Type.STRING },
                reference: { type: Type.STRING },
                status: { type: Type.STRING }
              }
            }
          },
          clinical_notes: { type: Type.STRING },
          summary: { type: Type.STRING },
          ai_opinion: { type: Type.STRING },
          flowchart_data: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                label: { type: Type.STRING },
                type: { type: Type.STRING },
                next: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          }
        }
      }
    }
  });

  return JSON.parse(response.text || "{}");
};

export const chatWithCase = async (caseData: any, userMessage: string, history: any[]) => {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are an AI medical assistant for DT Clinical Case Library. 
    You have access to the following clinical case data: ${JSON.stringify(caseData)}.
    Answer user queries based on this data. Use a professional yet soft tone.
    Provide data analysis when requested.
  `;

  const chat = ai.chats.create({
    model,
    config: { systemInstruction }
  });

  // We should ideally pass history here, but for simplicity:
  const response = await chat.sendMessage({ message: userMessage });
  return response.text;
};
