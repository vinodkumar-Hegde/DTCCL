import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || "" });

const extractJSON = (text: string) => {
  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    return JSON.parse(text);
  } catch (e) {
    console.error("Failed to parse JSON from Gemini response:", text);
    throw e;
  }
};

export const analyzeClinicalPDF = async (text: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: [
      {
        text: `Analyze the following clinical case text and extract structured information. 
        CRITICAL: EXTRACT ALL DETAILS. DO NOT SUMMARIZE. Capture every lab value, every symptom, and every clinical note mentioned.
        Determine the most appropriate Subject (Medicine, Surgery, ENT, OBG, Pediatrics) and Super Speciality.
        Return a JSON object matching this schema:
        {
          "subject": "Medicine | Surgery | ENT | OBG | Pediatrics",
          "speciality": "e.g. Cardiology, Neurology, Gastroenterology, General Surgery, Orthopedics, Neurosurgery, Otology, Rhinology, Obstetrics, Gynecology, Neonatology, Pediatric Cardiology",
          "disease": "The specific diagnosis",
          "title": "A descriptive title for the case",
          "history": {
            "chief_complaints": ["string"],
            "history_of_present_illness": "string",
            "past_history": "string",
            "family_history": "string",
            "personal_history": "string"
          },
          "lab_reports": [
            { "parameter": "string", "value": "string", "unit": "string", "reference": "string", "status": "normal | abnormal" }
          ],
          "imaging": [
            { "type": "string", "url": "string", "findings": "string" }
          ],
          "clinical_notes": [
            { "day": "Day 1", "note": "string" }
          ],
          "flowchart_data": [
            { "id": "1", "label": "Initial Presentation", "type": "step" },
            { "id": "2", "label": "Diagnostic Workup", "type": "decision" },
            { "id": "3", "label": "Final Outcome", "type": "outcome" }
          ],
          "summary": "A brief summary of the case",
          "ai_opinion": "Expert medical opinion on the case"
        }

        Text: ${text}`
      }
    ],
    config: {
      responseMimeType: "application/json"
    }
  });

  return extractJSON(response.text);
};

export const analyzeClinicalMultimodal = async (text: string, images: { data: string, mimeType: string }[]) => {
  const imageParts = images.map(img => ({
    inlineData: {
      data: img.data,
      mimeType: img.mimeType
    }
  }));

  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: [
      {
        parts: [
          ...imageParts,
          {
            text: `Analyze this clinical case. I have provided text extracted from a PDF and several clinical images (X-Rays, ECGs, etc.).
            INTEGRATE ALL INFORMATION: Extract comprehensive history, lab results, clinical progress, and detailed imaging findings. 
            CRITICAL: DO NOT SUMMARIZE. Capture every detail from the PDF and the images.
            The images should be described in the "imaging" section.
            Determine the most appropriate Subject (Medicine, Surgery, ENT, OBG, Pediatrics) and Super Speciality.
            Return a JSON object matching this schema:
            {
              "subject": "Medicine | Surgery | ENT | OBG | Pediatrics",
              "speciality": "e.g. Cardiology, Neurology, Gastroenterology, General Surgery, Orthopedics, Neurosurgery, Otology, Rhinology, Obstetrics, Gynecology, Neonatology, Pediatric Cardiology",
              "disease": "The specific diagnosis",
              "title": "A descriptive title for the case",
              "history": {
                "chief_complaints": ["string"],
                "history_of_present_illness": "string",
                "past_history": "string",
                "family_history": "string",
                "personal_history": "string"
              },
              "lab_reports": [
                { "parameter": "string", "value": "string", "unit": "string", "reference": "string", "status": "normal | abnormal" }
              ],
              "imaging": [
                { "type": "e.g. X-Ray", "url": "base64_data_or_placeholder", "findings": "Detailed findings from the image" }
              ],
              "clinical_notes": [
                { "day": "Day 1", "note": "string" }
              ],
              "flowchart_data": [
                { "id": "1", "label": "Initial Presentation", "type": "step" },
                { "id": "2", "label": "Diagnostic Workup", "type": "decision" },
                { "id": "3", "label": "Final Outcome", "type": "outcome" }
              ],
              "summary": "Brief summary of the findings",
              "ai_opinion": "Expert interpretation of the case"
            }

            PDF Text: ${text}`
          }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json"
    }
  });

  return extractJSON(response.text);
};

export const analyzeClinicalImage = async (base64Image: string, mimeType: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-image",
    contents: [
      {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType
            }
          },
          {
            text: `Analyze this clinical image (X-Ray, ECG, etc.) and provide a comprehensive structured clinical case.
            EXTRACT ALL DETAILS visible in the image and infer potential clinical progression.
            CRITICAL: DO NOT SUMMARIZE.
            Determine the most appropriate Subject (Medicine, Surgery, ENT, OBG, Pediatrics) and Super Speciality.
            Return a JSON object matching this schema:
            {
              "subject": "Medicine | Surgery | ENT | OBG | Pediatrics",
              "speciality": "e.g. Cardiology, Neurology, Gastroenterology, General Surgery, Orthopedics, Neurosurgery, Otology, Rhinology, Obstetrics, Gynecology, Neonatology, Pediatric Cardiology",
              "disease": "The specific diagnosis suggested by the image",
              "title": "A descriptive title for the case",
              "history": {
                "chief_complaints": ["string"],
                "history_of_present_illness": "string",
                "past_history": "string",
                "family_history": "string",
                "personal_history": "string"
              },
              "lab_reports": [],
              "imaging": [
                { "type": "e.g. X-Ray", "url": "base64_data_or_placeholder", "findings": "Detailed findings from the image" }
              ],
              "clinical_notes": [
                { "day": "Day 1", "note": "string" }
              ],
              "flowchart_data": [
                { "id": "1", "label": "Initial Presentation", "type": "step" },
                { "id": "2", "label": "Diagnostic Workup", "type": "decision" },
                { "id": "3", "label": "Final Outcome", "type": "outcome" }
              ],
              "summary": "Brief summary of the findings",
              "ai_opinion": "Expert interpretation of the image"
            }`
          }
        ]
      }
    ]
  });

  return extractJSON(response.text);
};
