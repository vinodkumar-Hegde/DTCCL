import React, { useState } from 'react';
import { BookOpen, User, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Landing from './pages/Landing';
import Admin from './pages/Admin';
import SubjectDetail from './pages/SubjectDetail';
import CaseDetail from './pages/CaseDetail';
import { Subject } from './types';

function App() {
  const [currentPage, setCurrentPage] = useState<'landing' | 'admin' | 'subject' | 'case'>('landing');
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [selectedCaseId, setSelectedCaseId] = useState<number | null>(null);
  const [selectedSpeciality, setSelectedSpeciality] = useState<any>(null);
  const [preselectedDiseaseId, setPreselectedDiseaseId] = useState<number | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const navigateTo = (page: 'landing' | 'admin' | 'subject' | 'case', data?: any, extra?: any) => {
    if (page === 'subject') {
      setSelectedSubject(data);
      setSelectedSpeciality(extra || null);
    }
    if (page === 'case') setSelectedCaseId(data);
    setCurrentPage(page);
    setIsSidebarOpen(false);
  };

  const handleSelectSpeciality = (subject: Subject, speciality: any) => {
    navigateTo('subject', subject, speciality);
  };

  // Helper to find subject and speciality by id
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [specialities, setSpecialities] = useState<any[]>([]);
  React.useEffect(() => {
    // Fetch subjects and specialities for navigation after upload
    import('./services/supabaseClient').then(({ supabase }) => {
      supabase.from('subjects').select('*').then(({ data }) => setSubjects(data || []));
      supabase.from('specialities').select('*').then(({ data }) => setSpecialities(data || []));
    });
  }, []);

  const handleAdminUploadSuccess = (subjectId: number, specialityId: number, diseaseId: number) => {
    // Find subject and speciality objects
    const subject = subjects.find(s => s.id === subjectId) || null;
    const speciality = specialities.find(s => s.id === specialityId) || null;
    setSelectedSubject(subject);
    setSelectedSpeciality(speciality);
    setPreselectedDiseaseId(diseaseId);
    setCurrentPage('subject');
    setIsSidebarOpen(false);
  };
    return (
    <div className="min-h-screen bg-white text-slate-900 font-sans">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div 
            className="flex items-center gap-2 cursor-pointer" 
            onClick={() => navigateTo('landing')}
          >
            <div className="w-10 h-10 bg-blue-900 rounded-lg flex items-center justify-center">
              <BookOpen className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-blue-900 leading-none">DocTutorials</h1>
              <p className="text-[10px] uppercase tracking-widest text-slate-500 font-semibold">Clinical Case Library</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => navigateTo('landing')} className="text-sm font-medium hover:text-blue-600 transition-colors">Library</button>
            <button onClick={() => navigateTo('admin')} className="text-sm font-medium hover:text-blue-600 transition-colors">Admin Panel</button>
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
              <User className="w-4 h-4 text-slate-600" />
            </div>
          </div>

          <button className="md:hidden" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
            {isSidebarOpen ? <X /> : <Menu />}
          </button>
        </div>
      </nav>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className="fixed inset-0 z-40 bg-white md:hidden pt-20 px-6"
          >
            <div className="flex flex-col gap-6">
              <button onClick={() => navigateTo('landing')} className="text-lg font-semibold text-left">Library</button>
              <button onClick={() => navigateTo('admin')} className="text-lg font-semibold text-left">Admin Panel</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {currentPage === 'landing' && (
            <motion.div key="landing" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <Landing 
                onSelectSubject={(s) => navigateTo('subject', s)} 
                onSelectCase={(id) => navigateTo('case', id)}
                onSelectSpeciality={handleSelectSpeciality}
              />
            </motion.div>
          )}
          {currentPage === 'admin' && (
            <motion.div key="admin" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <Admin onBack={() => navigateTo('landing')} onUploadSuccess={handleAdminUploadSuccess} />
            </motion.div>
          )}
          {currentPage === 'subject' && selectedSubject && (
            <motion.div key="subject" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <SubjectDetail 
                subject={selectedSubject} 
                preselectedSpeciality={selectedSpeciality}
                preselectedDiseaseId={preselectedDiseaseId}
                onSelectCase={(id) => navigateTo('case', id)} 
                onBack={() => navigateTo('landing')} 
              />
            </motion.div>
          )}
          {currentPage === 'case' && selectedCaseId && (
            <motion.div key="case" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <CaseDetail caseId={selectedCaseId} onBack={() => navigateTo('subject', selectedSubject)} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-slate-50 border-t border-slate-100 mt-20 py-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-slate-500 text-sm">© 2024 DocTutorials Clinical Case Library. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;

