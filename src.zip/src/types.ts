export interface Subject {
  id: number;
  name: string;
  case_count?: number;
}

export interface Speciality {
  id: number;
  subject_id: number;
  name: string;
}

export interface Disease {
  id: number;
  speciality_id: number;
  name: string;
}

export interface ClinicalCase {
  id: number;
  disease_id: number;
  title: string;
  history: string; // JSON string
  lab_reports: string; // JSON string
  imaging: string; // JSON string
  clinical_notes: string; // JSON string
  flowchart_data: string; // JSON string
  summary: string;
  ai_opinion: string;
  comparison_case_id?: number;
  video_url?: string;
  is_new?: number;
  created_at?: string;
}

export interface LabReport {
  parameter: string;
  value: string;
  reference: string;
  unit: string;
  status: 'normal' | 'abnormal';
}

export interface HistoryData {
  chief_complaints: string[];
  history_of_present_illness: string;
  past_history: string;
  family_history: string;
  personal_history: string;
}

export interface ImagingData {
  type: string;
  url: string;
  findings: string;
}

export interface FlowchartNode {
  id: string;
  label: string;
  type: 'step' | 'decision' | 'outcome';
  next?: string[];
}
