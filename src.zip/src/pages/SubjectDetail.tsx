
import React, { useState, useEffect } from 'react';
import { ArrowLeft, ChevronRight, BookOpen, Activity, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Subject, Speciality, Disease, ClinicalCase } from '../types';
import { supabase } from '../services/supabaseClient';

interface SubjectDetailProps {
  subject: Subject;
  preselectedSpeciality?: Speciality | null;
  preselectedDiseaseId?: number | null;
  onSelectCase: (id: number) => void;
  onBack: () => void;
}

const SubjectDetail: React.FC<SubjectDetailProps> = ({ subject, preselectedSpeciality, preselectedDiseaseId, onSelectCase, onBack }) => {
  const [specialities, setSpecialities] = useState<Speciality[]>([]);
  const [selectedSpeciality, setSelectedSpeciality] = useState<Speciality | null>(preselectedSpeciality || null);
  const [diseases, setDiseases] = useState<Disease[]>([]);
  const [selectedDisease, setSelectedDisease] = useState<Disease | null>(null);
  const [cases, setCases] = useState<ClinicalCase[]>([]);

  useEffect(() => {
    async function fetchSpecialities() {
      const { data, error } = await supabase
        .from('specialities')
        .select('*')
        .eq('subject_id', subject.id);
      if (!error) setSpecialities(data || []);
    }
    fetchSpecialities();
  }, [subject]);

  // If preselectedSpeciality changes (e.g., via navigation), select it
  useEffect(() => {
    if (preselectedSpeciality) {
      setSelectedSpeciality(preselectedSpeciality);
      setSelectedDisease(null);
      setCases([]);
      async function fetchDiseases() {
        const { data, error } = await supabase
          .from('diseases')
          .select('*')
          .eq('speciality_id', preselectedSpeciality.id);
        if (!error) {
          setDiseases(data || []);
          // If preselectedDiseaseId is provided, auto-select that disease
          if (preselectedDiseaseId && data) {
            const found = data.find((d: any) => d.id === preselectedDiseaseId);
            if (found) {
              setSelectedDisease(found);
              // Fetch cases for this disease
              const { data: caseData, error: caseError } = await supabase
                .from('cases')
                .select('*')
                .eq('disease_id', preselectedDiseaseId);
              if (!caseError) setCases(caseData || []);
            }
          }
        }
      }
      fetchDiseases();
    }
  }, [preselectedSpeciality, preselectedDiseaseId]);

  const handleSpecialityClick = async (spec: Speciality) => {
    setSelectedSpeciality(spec);
    setSelectedDisease(null);
    setCases([]);
    const { data, error } = await supabase
      .from('diseases')
      .select('*')
      .eq('speciality_id', spec.id);
    if (!error) setDiseases(data || []);
  };

  const handleDiseaseClick = async (disease: Disease) => {
    setSelectedDisease(disease);
    const { data, error } = await supabase
      .from('cases')
      .select('*')
      .eq('disease_id', disease.id);
    if (!error) setCases(data || []);
  };

  return (
    <div className="space-y-8 pb-10">
      {/* Sticky Header */}
      <div className="sticky top-0 z-40 bg-slate-50/80 backdrop-blur-md py-4 -mx-4 px-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200">
        <button onClick={onBack} className="flex items-center text-slate-500 hover:text-blue-600 transition-colors font-bold">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Library
        </button>
        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
          <span className="text-blue-600">{subject.name}</span>
          {selectedSpeciality && (
            <>
              <ChevronRight className="w-3 h-3" />
              <span className="text-slate-600">{selectedSpeciality.name}</span>
            </>
          )}
          {selectedDisease && (
            <>
              <ChevronRight className="w-3 h-3" />
              <span className="text-indigo-600">{selectedDisease.name}</span>
            </>
          )}
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-blue-900 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-900/20">
          <BookOpen className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-3xl font-bold text-slate-800">{subject.name}</h2>
          <p className="text-slate-500">Follow the steps to find your clinical case.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Step 1: Specialities Column */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-4 p-6 bg-white border-2 border-blue-100 rounded-3xl shadow-sm"
        >
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold text-xs">
              01
            </div>
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Super Specialities</h3>
          </div>
          <div className="space-y-2">
            {specialities.map(spec => (
              <button
                key={spec.id}
                onClick={() => handleSpecialityClick(spec)}
                className={`w-full text-left px-4 py-4 rounded-2xl transition-all flex items-center justify-between group ${
                  selectedSpeciality?.id === spec.id 
                    ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/20' 
                    : 'bg-slate-50 border border-slate-100 text-slate-700 hover:border-blue-200 hover:bg-white'
                }`}
              >
                <span className="font-bold text-sm">{spec.name}</span>
                <ChevronRight className={`w-4 h-4 transition-transform ${selectedSpeciality?.id === spec.id ? 'rotate-90' : 'group-hover:translate-x-1'}`} />
              </button>
            ))}
          </div>
        </motion.div>

        {/* Step 2: Diseases Column */}
        <AnimatePresence>
          {selectedSpeciality && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="space-y-4 p-6 bg-white border-2 border-indigo-100 rounded-3xl shadow-sm"
            >
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center font-bold text-xs">
                  02
                </div>
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Diseases</h3>
              </div>
              <div className="space-y-2">
                {diseases.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs font-medium">
                    No diseases found in this speciality
                  </div>
                ) : (
                  diseases.map(disease => (
                    <button
                      key={disease.id}
                      onClick={() => handleDiseaseClick(disease)}
                      className={`w-full text-left px-4 py-4 rounded-2xl transition-all flex items-center justify-between group ${
                        selectedDisease?.id === disease.id 
                          ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' 
                          : 'bg-slate-50 border border-slate-100 text-slate-700 hover:border-indigo-200 hover:bg-white'
                      }`}
                    >
                      <span className="font-bold text-sm">{disease.name}</span>
                      <ChevronRight className={`w-4 h-4 transition-transform ${selectedDisease?.id === disease.id ? 'rotate-90' : 'group-hover:translate-x-1'}`} />
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Step 3: Cases Column */}
        <AnimatePresence>
          {selectedDisease && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="space-y-4 p-6 bg-white border-2 border-emerald-100 rounded-3xl shadow-sm"
            >
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-lg flex items-center justify-center font-bold text-xs">
                  03
                </div>
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Clinical Cases</h3>
              </div>
              <div className="space-y-4">
                {cases.length === 0 ? (
                  <div className="py-20 text-center text-slate-400 text-xs font-medium">
                    No cases registered for this disease yet
                  </div>
                ) : (
                  cases.map(c => (
                    <motion.div
                      key={c.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      onClick={() => onSelectCase(c.id)}
                      className="p-5 bg-slate-50 border border-slate-100 rounded-2xl shadow-sm hover:shadow-md hover:border-emerald-200 hover:bg-white transition-all cursor-pointer group"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 bg-white border border-slate-100 text-slate-400 text-[9px] font-bold uppercase rounded-md tracking-tighter">ID: #{c.id}</span>
                          {c.is_new === 1 && (
                            <span className="px-2 py-1 bg-blue-100 text-blue-600 text-[9px] font-bold rounded-md uppercase animate-pulse">New</span>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                          <div className="w-1.5 h-1.5 bg-emerald-200 rounded-full" />
                        </div>
                      </div>
                      <h4 className="text-base font-bold text-slate-800 mb-2 group-hover:text-emerald-600 transition-colors line-clamp-1">{c.title}</h4>
                      <p className="text-slate-500 text-xs line-clamp-2 mb-4 leading-relaxed">{c.summary}</p>
                      <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                        <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Open Case</span>
                        <ChevronRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default SubjectDetail;
