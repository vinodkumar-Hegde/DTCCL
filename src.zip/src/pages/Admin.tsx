import { ArrowLeft, Upload, CheckCircle, AlertCircle, Loader2, Database, LayoutDashboard, FileText, Image as ImageIcon, Trash2, Edit3, Save, X, Activity, BarChart3, PieChart, Plus, Minus } from 'lucide-react';
import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { supabase } from '../services/supabaseClient';
import { analyzeClinicalImage } from '../services/geminiService';
interface AdminProps {
  onBack: () => void;
  onUploadSuccess?: (subjectId: number, specialityId: number, diseaseId: number) => void;
}

const Admin: React.FC<AdminProps> = ({ onBack, onUploadSuccess }) => {
  // Super Speciality management state
  const [newSpeciality, setNewSpeciality] = useState("");
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [specialityAddStatus, setSpecialityAddStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [specialities, setSpecialities] = useState<Speciality[]>([]);

  useEffect(() => {
    if (selectedSubjectId) fetchSpecialities(selectedSubjectId);
  }, [selectedSubjectId]);

  const fetchSpecialities = async (subjectId: number) => {
    const { data, error } = await supabase
      .from('specialities')
      .select('*')
      .eq('subject_id', subjectId);
    if (!error) setSpecialities(data || []);
  };

  const handleAddSpeciality = async () => {
    if (!newSpeciality.trim() || !selectedSubjectId) return;
    setSpecialityAddStatus('idle');
    const { error } = await supabase
      .from('specialities')
      .insert([{ name: newSpeciality.trim(), subject_id: selectedSubjectId }]);
    if (error) {
      setSpecialityAddStatus('error');
    } else {
      setSpecialityAddStatus('success');
      setNewSpeciality("");
      fetchSpecialities(selectedSubjectId);
    }
  };

  // Subject management state
  const [newSubject, setNewSubject] = useState("");
  const [subjectAddStatus, setSubjectAddStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [subjects, setSubjects] = useState<Subject[]>([]);

  useEffect(() => {
    fetchSubjects();
  }, []);

  const fetchSubjects = async () => {
    const { data, error } = await supabase
      .from('subjects')
      .select('*');
    if (!error) setSubjects(data || []);
  };

  const handleAddSubject = async () => {
    if (!newSubject.trim()) return;
    setSubjectAddStatus('idle');
    const { error } = await supabase
      .from('subjects')
      .insert([{ name: newSubject.trim() }]);
    if (error) {
      setSubjectAddStatus('error');
    } else {
      setSubjectAddStatus('success');
      setNewSubject("");
      fetchSubjects();
    }
  };
  const [view, setView] = useState<'dashboard' | 'upload' | 'manage'>('dashboard');
  const [stats, setStats] = useState<{ totalCases: number, casesBySubject: { name: string, count: number }[] } | null>(null);
  const [cases, setCases] = useState<any[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'extracting' | 'review' | 'saving' | 'success' | 'error'>('idle');
  const [extractedData, setExtractedData] = useState<any>(null);
  const [editingCase, setEditingCase] = useState<any>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  useEffect(() => {
    fetchStats();
    fetchCases();
  }, []);

  const fetchStats = async () => {
    // Example: count total cases and group by subject
    const { data: totalCasesData, error: totalCasesError } = await supabase
      .from('cases')
      .select('id');
    const { data: casesBySubjectData, error: casesBySubjectError } = await supabase
      .from('subjects')
      .select('name, cases(id)');
    setStats({
      totalCases: totalCasesData ? totalCasesData.length : 0,
      casesBySubject: casesBySubjectData ? casesBySubjectData.map(s => ({ name: s.name, count: s.cases ? s.cases.length : 0 })) : []
    });
  };

  const fetchCases = async () => {
    const { data, error } = await supabase
      .from('cases')
      .select('*');
    if (!error) setCases(data || []);
  };

  const extractTextFromPDF = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      const strings = content.items.map((item: any) => item.str);
      fullText += strings.join(' ') + '\n';
    }
    return fullText;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  const handleProcessFiles = async () => {
    if (selectedFiles.length === 0) return;

    setIsUploading(true);
    setUploadStatus('extracting');

    try {
      const pdfFile = selectedFiles.find(f => f.type === 'application/pdf');
      const imageFiles = selectedFiles.filter(f => f.type.startsWith('image/'));

      let data;

      if (pdfFile && imageFiles.length > 0) {
        // Multimodal analysis
        const text = await extractTextFromPDF(pdfFile);
        const imagesData = await Promise.all(imageFiles.map(async (file) => {
          const reader = new FileReader();
          const base64Promise = new Promise<string>((resolve) => {
            reader.onload = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(file);
          });
          const base64 = await base64Promise;
          return { data: base64, mimeType: file.type, originalFile: file };
        }));
        data = await analyzeClinicalMultimodal(text, imagesData.map(d => ({ data: d.data, mimeType: d.mimeType })));
        
        // Map original images to imaging data
        if (data && data.imaging) {
          data.imaging = data.imaging.map((img: any, idx: number) => {
            if (imagesData[idx]) {
              return {
                ...img,
                url: `data:${imagesData[idx].mimeType};base64,${imagesData[idx].data}`
              };
            }
            return img;
          });
        }
      } else if (pdfFile) {
        // PDF only
        const text = await extractTextFromPDF(pdfFile);
        data = await analyzeClinicalPDF(text);
      } else if (imageFiles.length > 0) {
        // Images only (process first one for now, or could be multimodal too)
        const file = imageFiles[0];
        const reader = new FileReader();
        const base64Promise = new Promise<string>((resolve) => {
          reader.onload = () => resolve((reader.result as string).split(',')[1]);
          reader.readAsDataURL(file);
        });
        const base64 = await base64Promise;
        data = await analyzeClinicalImage(base64, file.type);
      }

      if (data) {
        setExtractedData(data);
        setUploadStatus('review');
      } else {
        setUploadStatus('error');
      }
    } catch (err) {
      console.error(err);
      setUploadStatus('error');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSaveCase = async (caseData: any) => {
    setUploadStatus('saving');
    try {
      const { error, data } = await supabase
        .from('cases')
        .insert([{ ...caseData }])
        .select();
      if (!error) {
        setUploadStatus('success');
        setExtractedData(null);
        setSelectedFiles([]);
        fetchStats();
        fetchCases();
        // Call the callback with subjectId, specialityId, diseaseId if available
        if (onUploadSuccess && data && data.length > 0) {
          // We need to fetch the disease, then speciality, then subject
          const diseaseId = data[0].disease_id;
          // Fetch disease
          const { data: diseaseData } = await supabase
            .from('diseases')
            .select('id,speciality_id')
            .eq('id', diseaseId)
            .single();
          if (diseaseData) {
            const specialityId = diseaseData.speciality_id;
            // Fetch speciality
            const { data: specialityData } = await supabase
              .from('specialities')
              .select('id,subject_id')
              .eq('id', specialityId)
              .single();
            if (specialityData) {
              const subjectId = specialityData.subject_id;
              onUploadSuccess(subjectId, specialityId, diseaseId);
            }
          }
        }
        setTimeout(() => setUploadStatus('idle'), 3000);
      } else {
        setUploadStatus('error');
      }
    } catch (err) {
      setUploadStatus('error');
    }
  };

  const handleDeleteCase = async (id: number) => {
    if (!confirm('Are you sure you want to delete this case?')) return;
    await supabase.from('cases').delete().eq('id', id);
    fetchStats();
    fetchCases();
  };

  const handleUpdateCase = async (id: number, updatedData: any) => {
    await supabase
      .from('cases')
      .update({ ...updatedData })
      .eq('id', id);
    setEditingCase(null);
    fetchCases();
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center text-slate-500 hover:text-blue-600 transition-colors font-bold">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Library
        </button>
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button 
            onClick={() => setView('dashboard')}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${view === 'dashboard' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <LayoutDashboard className="w-4 h-4" /> Dashboard
          </button>
          <button 
            onClick={() => setView('upload')}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${view === 'upload' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Upload className="w-4 h-4" /> Upload
          </button>
          <button 
            onClick={() => setView('manage')}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${view === 'manage' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Database className="w-4 h-4" /> Manage Cases
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        <div>
          {/* Subject Management UI */}
          <div className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-sm mb-8">
            <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" /> Manage Subjects
            </h3>
            <div className="flex gap-4 items-center mb-4">
              <input
                type="text"
                value={newSubject}
                onChange={e => setNewSubject(e.target.value)}
                placeholder="Enter new subject name"
                className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
              <button
                onClick={handleAddSubject}
                className="px-6 py-2 bg-blue-900 text-white font-bold rounded-xl shadow-lg hover:bg-blue-800 transition-all"
              >
                Add Subject
              </button>
              {subjectAddStatus === 'success' && <span className="text-green-600 font-bold">Added!</span>}
              {subjectAddStatus === 'error' && <span className="text-red-600 font-bold">Error!</span>}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
              {subjects.map(s => (
                <div key={s.id} className="text-center p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter mb-2">ID: {s.id}</div>
                  <div className="text-lg font-bold text-blue-900 mb-1">{s.name}</div>
                </div>
              ))}
            </div>
            {/* Super Speciality Management UI */}
            <div className="mt-10">
              <h4 className="text-lg font-bold text-slate-700 mb-4">Add Super Speciality</h4>
              <div className="flex gap-4 items-center mb-4">
                <select
                  value={selectedSubjectId ?? ''}
                  onChange={e => setSelectedSubjectId(Number(e.target.value) || null)}
                  className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="">Select Subject</option>
                  {subjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
                <input
                  type="text"
                  value={newSpeciality}
                  onChange={e => setNewSpeciality(e.target.value)}
                  placeholder="Enter super speciality name"
                  className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  disabled={!selectedSubjectId}
                />
                <button
                  onClick={handleAddSpeciality}
                  className="px-6 py-2 bg-indigo-700 text-white font-bold rounded-xl shadow-lg hover:bg-indigo-800 transition-all"
                  disabled={!selectedSubjectId}
                >
                  Add Super Speciality
                </button>
                {specialityAddStatus === 'success' && <span className="text-green-600 font-bold">Added!</span>}
                {specialityAddStatus === 'error' && <span className="text-red-600 font-bold">Error!</span>}
              </div>
              {selectedSubjectId && (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                  {specialities.map(sp => (
                    <div key={sp.id} className="text-center p-4 bg-indigo-50 rounded-2xl border border-indigo-100">
                      <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-tighter mb-2">ID: {sp.id}</div>
                      <div className="text-lg font-bold text-indigo-900 mb-1">{sp.name}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          {view === 'dashboard' && (
            <motion.div key="dashboard" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-blue-900 text-white p-8 rounded-[2.5rem] shadow-xl shadow-blue-900/20">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
                      <FileText className="w-6 h-6" />
                    </div>
                    <span className="text-blue-300 text-xs font-bold uppercase tracking-widest">Total Cases</span>
                  </div>
                  <div className="text-5xl font-bold mb-2">{stats?.totalCases || 0}</div>
                <p className="text-blue-200 text-sm">Clinical cases analyzed by AI</p>
              </div>
              
              <div className="md:col-span-2 bg-white border border-slate-100 p-8 rounded-[2.5rem] shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-blue-600" /> Distribution by Subject
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                  {stats?.casesBySubject.map(s => (
                    <div key={s.name} className="text-center p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="text-2xl font-bold text-blue-900 mb-1">{s.count}</div>
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{s.name}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-sm">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Recent Activity</h3>
              <div className="space-y-4">
                {cases.slice(0, 5).map(c => (
                  <div key={c.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-blue-600 shadow-sm">
                        <Activity className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-bold text-slate-800">{c.title}</div>
                        <div className="text-xs text-slate-400">{c.subject_name} • {c.speciality_name}</div>
                      </div>
                    </div>
                    <div className="text-xs font-bold text-slate-400">
                      {new Date(c.created_at).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {view === 'upload' && (
          <motion.div key="upload" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="max-w-4xl mx-auto">
            {uploadStatus === 'review' ? (
              <CaseReviewer 
                data={extractedData} 
                onSave={handleSaveCase} 
                onCancel={() => setUploadStatus('idle')} 
                isSaving={isUploading}
              />
            ) : (
              <div className="bg-white border border-slate-100 rounded-[2.5rem] p-12 shadow-sm text-center space-y-8">
                <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mx-auto shadow-inner">
                  <Upload className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-slate-800 mb-2">Upload Clinical Case</h3>
                  <p className="text-slate-500">Upload a PDF case sheet AND clinical images (X-Ray, ECG). AI will integrate them into a single case.</p>
                </div>
                
                <div className="space-y-6">
                  <label className="cursor-pointer group block">
                    <input type="file" className="hidden" multiple onChange={handleFileChange} />
                    <div className="p-12 border-2 border-dashed border-slate-200 rounded-[2rem] hover:border-blue-400 hover:bg-blue-50 transition-all">
                      <div className="flex justify-center gap-4 mb-4">
                        <FileText className="w-8 h-8 text-slate-400 group-hover:text-blue-600" />
                        <ImageIcon className="w-8 h-8 text-slate-400 group-hover:text-indigo-600" />
                      </div>
                      <div className="font-bold text-slate-700 text-lg">Select PDF and/or Images</div>
                      <div className="text-sm text-slate-400 mt-1">You can select multiple files at once</div>
                    </div>
                  </label>

                  {selectedFiles.length > 0 && (
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-left">
                      <div className="text-xs font-bold text-slate-400 uppercase mb-4 tracking-widest">Selected Files ({selectedFiles.length})</div>
                      <div className="space-y-2">
                        {selectedFiles.map((f, i) => (
                          <div key={i} className="flex items-center justify-between bg-white p-3 rounded-xl border border-slate-100">
                            <div className="flex items-center gap-3">
                              {f.type === 'application/pdf' ? <FileText className="w-4 h-4 text-blue-500" /> : <ImageIcon className="w-4 h-4 text-indigo-500" />}
                              <span className="text-sm font-medium text-slate-700 truncate max-w-[200px]">{f.name}</span>
                            </div>
                            <span className="text-[10px] text-slate-400 uppercase">{(f.size / 1024 / 1024).toFixed(2)} MB</span>
                          </div>
                        ))}
                      </div>
                      <button 
                        onClick={handleProcessFiles}
                        disabled={isUploading}
                        className="w-full mt-6 py-4 bg-blue-900 text-white font-bold rounded-xl shadow-lg shadow-blue-900/20 hover:bg-blue-800 transition-all flex items-center justify-center gap-2"
                      >
                        {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Activity className="w-5 h-5" />}
                        {isUploading ? 'Analyzing with AI...' : 'Process with AI'}
                      </button>
                    </div>
                  )}
                </div>

                {uploadStatus === 'success' && (
                  <div className="p-4 bg-emerald-50 text-emerald-700 rounded-2xl font-bold flex items-center justify-center gap-2">
                    <CheckCircle className="w-5 h-5" /> Case successfully uploaded and indexed!
                  </div>
                )}
                {uploadStatus === 'error' && (
                  <div className="p-4 bg-red-50 text-red-700 rounded-2xl font-bold flex items-center justify-center gap-2">
                    <AlertCircle className="w-5 h-5" /> Analysis failed. Please check the files and try again.
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}

        {view === 'manage' && (
          <motion.div key="manage" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
            <div className="bg-white border border-slate-100 rounded-[2.5rem] overflow-hidden shadow-sm">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100">
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Case Title</th>
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Subject</th>
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Speciality</th>
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {cases.map(c => (
                    <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-800">{c.title}</div>
                        <div className="text-[10px] text-slate-400">ID: #{c.id}</div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">{c.subject_name}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{c.speciality_name}</td>
                      <td className="px-6 py-4">
                        {c.is_new ? (
                          <span className="px-2 py-1 bg-blue-100 text-blue-600 text-[9px] font-bold rounded-md uppercase">New</span>
                        ) : (
                          <span className="px-2 py-1 bg-slate-100 text-slate-400 text-[9px] font-bold rounded-md uppercase">Indexed</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => {
                              const parsedCase = {
                                ...c,
                                clinical_notes: typeof c.clinical_notes === 'string' ? JSON.parse(c.clinical_notes || '[]') : c.clinical_notes
                              };
                              setEditingCase(parsedCase);
                            }}
                            className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeleteCase(c.id)}
                            className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
        </div>
      </AnimatePresence>

      {/* Edit Modal */}
      <AnimatePresence>
        {editingCase && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-[2.5rem] shadow-2xl p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold text-slate-800">Edit Case Details</h3>
                <button onClick={() => setEditingCase(null)} className="p-2 hover:bg-slate-100 rounded-full transition-all">
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase">Case Title</label>
                    <input 
                      type="text" 
                      value={editingCase.title} 
                      onChange={(e) => setEditingCase({...editingCase, title: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase">Status</label>
                    <select 
                      value={editingCase.is_new} 
                      onChange={(e) => setEditingCase({...editingCase, is_new: parseInt(e.target.value)})}
                      className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    >
                      <option value={1}>New</option>
                      <option value={0}>Indexed</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase">Summary</label>
                  <textarea 
                    value={editingCase.summary} 
                    onChange={(e) => setEditingCase({...editingCase, summary: e.target.value})}
                    rows={4}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase">AI Opinion</label>
                  <textarea 
                    value={editingCase.ai_opinion} 
                    onChange={(e) => setEditingCase({...editingCase, ai_opinion: e.target.value})}
                    rows={4}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-400 uppercase">Clinical Notes (Day-wise)</label>
                    <button 
                      onClick={() => {
                        const nextDay = (editingCase.clinical_notes?.length || 0) + 1;
                        const newNotes = [...(editingCase.clinical_notes || []), { day: `Day ${nextDay}`, note: '' }];
                        setEditingCase({ ...editingCase, clinical_notes: newNotes });
                      }}
                      className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700"
                    >
                      <Plus className="w-3 h-3" /> Add Day
                    </button>
                  </div>
                  <div className="space-y-3">
                    {(editingCase.clinical_notes || []).map((note: any, idx: number) => (
                      <div key={idx} className="flex gap-3 items-start">
                        <input 
                          type="text"
                          value={note.day}
                          onChange={(e) => {
                            const newNotes = [...editingCase.clinical_notes];
                            newNotes[idx] = { ...newNotes[idx], day: e.target.value };
                            setEditingCase({ ...editingCase, clinical_notes: newNotes });
                          }}
                          className="w-24 bg-slate-50 border border-slate-100 rounded-xl px-3 py-2 text-xs font-bold outline-none"
                        />
                        <textarea 
                          value={note.note}
                          onChange={(e) => {
                            const newNotes = [...editingCase.clinical_notes];
                            newNotes[idx] = { ...newNotes[idx], note: e.target.value };
                            setEditingCase({ ...editingCase, clinical_notes: newNotes });
                          }}
                          rows={2}
                          className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-2 text-sm outline-none resize-none"
                        />
                        <button 
                          onClick={() => {
                            const newNotes = editingCase.clinical_notes.filter((_: any, i: number) => i !== idx);
                            setEditingCase({ ...editingCase, clinical_notes: newNotes });
                          }}
                          className="p-2 text-slate-400 hover:text-red-600"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end gap-4 pt-6">
                  <button 
                    onClick={() => setEditingCase(null)}
                    className="px-6 py-3 text-slate-500 font-bold hover:text-slate-700 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => handleUpdateCase(editingCase.id, editingCase)}
                    className="px-8 py-3 bg-blue-900 text-white font-bold rounded-xl shadow-lg shadow-blue-900/20 hover:bg-blue-800 transition-all flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" /> Save Changes
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const CaseReviewer: React.FC<{ data: any, onSave: (data: any) => void, onCancel: () => void, isSaving: boolean }> = ({ data, onSave, onCancel, isSaving }) => {
  const [editedData, setEditedData] = useState(data);

  const handleAddNote = () => {
    const nextDay = editedData.clinical_notes.length + 1;
    setEditedData({
      ...editedData,
      clinical_notes: [...editedData.clinical_notes, { day: `Day ${nextDay}`, note: '' }]
    });
  };

  const handleRemoveNote = (index: number) => {
    const newNotes = editedData.clinical_notes.filter((_: any, i: number) => i !== index);
    setEditedData({ ...editedData, clinical_notes: newNotes });
  };

  const handleNoteChange = (index: number, field: 'day' | 'note', value: string) => {
    const newNotes = [...editedData.clinical_notes];
    newNotes[index] = { ...newNotes[index], [field]: value };
    setEditedData({ ...editedData, clinical_notes: newNotes });
  };

  return (
    <div className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-sm space-y-8 animate-in fade-in slide-in-from-bottom-4">
      <div className="flex items-center justify-between border-b border-slate-100 pb-6">
        <div>
          <h3 className="text-2xl font-bold text-slate-800">Review AI Extraction</h3>
          <p className="text-sm text-slate-500">Verify and edit the clinical data before indexing.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={onCancel} className="px-6 py-2 text-slate-500 font-bold hover:text-slate-700">Cancel</button>
          <button 
            onClick={() => onSave(editedData)}
            disabled={isSaving}
            className="px-8 py-2 bg-emerald-600 text-white font-bold rounded-xl shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 transition-all flex items-center gap-2"
          >
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
            Confirm & Save
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Detected Subject</label>
          <input 
            type="text" 
            value={editedData.subject} 
            onChange={(e) => setEditedData({...editedData, subject: e.target.value})}
            className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm font-bold text-blue-900 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Detected Speciality</label>
          <input 
            type="text" 
            value={editedData.speciality} 
            onChange={(e) => setEditedData({...editedData, speciality: e.target.value})}
            className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm font-bold text-indigo-900 focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Detected Disease</label>
          <input 
            type="text" 
            value={editedData.disease} 
            onChange={(e) => setEditedData({...editedData, disease: e.target.value})}
            className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm font-bold text-emerald-900 focus:ring-2 focus:ring-emerald-500 outline-none"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Case Title</label>
        <input 
          type="text" 
          value={editedData.title} 
          onChange={(e) => setEditedData({...editedData, title: e.target.value})}
          className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-base font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-4">
          <h4 className="font-bold text-slate-800 flex items-center gap-2"><Activity className="w-4 h-4 text-blue-600" /> Clinical Summary</h4>
          <textarea 
            value={editedData.summary} 
            onChange={(e) => setEditedData({...editedData, summary: e.target.value})}
            rows={6}
            className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3 text-sm text-slate-600 focus:ring-2 focus:ring-blue-500 outline-none resize-none"
          />
        </div>
        <div className="space-y-4">
          <h4 className="font-bold text-slate-800 flex items-center gap-2"><Activity className="w-4 h-4 text-emerald-600" /> AI Medical Opinion</h4>
          <textarea 
            value={editedData.ai_opinion} 
            onChange={(e) => setEditedData({...editedData, ai_opinion: e.target.value})}
            rows={6}
            className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3 text-sm text-slate-600 focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
          />
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="font-bold text-slate-800 flex items-center gap-2"><ImageIcon className="w-4 h-4 text-blue-600" /> Imaging Data</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(editedData.imaging || []).map((img: any, index: number) => (
            <div key={index} className="bg-slate-50 border border-slate-100 rounded-2xl overflow-hidden">
              <div className="aspect-video bg-slate-200 relative">
                {img.url ? (
                  <img src={img.url} alt={img.type} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400">
                    <ImageIcon className="w-8 h-8" />
                  </div>
                )}
                <div className="absolute top-2 left-2">
                  <input 
                    type="text" 
                    value={img.type} 
                    onChange={(e) => {
                      const newImaging = [...editedData.imaging];
                      newImaging[index] = { ...newImaging[index], type: e.target.value };
                      setEditedData({ ...editedData, imaging: newImaging });
                    }}
                    className="bg-black/50 backdrop-blur-md text-white text-[10px] font-bold uppercase rounded-full px-3 py-1 border-none outline-none w-24"
                  />
                </div>
              </div>
              <div className="p-4">
                <textarea 
                  value={img.findings} 
                  onChange={(e) => {
                    const newImaging = [...editedData.imaging];
                    newImaging[index] = { ...newImaging[index], findings: e.target.value };
                    setEditedData({ ...editedData, imaging: newImaging });
                  }}
                  rows={3}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-600 focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                  placeholder="Findings..."
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-bold text-slate-800">Day-wise Clinical Progress Notes</h4>
          <button 
            onClick={handleAddNote}
            className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700"
          >
            <Plus className="w-3 h-3" /> Add Day
          </button>
        </div>
        <div className="space-y-3">
          {editedData.clinical_notes.map((note: any, index: number) => (
            <div key={index} className="flex gap-4 items-start bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <div className="w-24 shrink-0">
                <input 
                  type="text" 
                  value={note.day} 
                  onChange={(e) => handleNoteChange(index, 'day', e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-slate-500 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
              <div className="flex-1">
                <textarea 
                  value={note.note} 
                  onChange={(e) => handleNoteChange(index, 'note', e.target.value)}
                  rows={2}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-600 focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                  placeholder="Enter clinical notes for this day..."
                />
              </div>
              <button 
                onClick={() => handleRemoveNote(index)}
                className="p-1 text-slate-300 hover:text-red-500 transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Admin;

