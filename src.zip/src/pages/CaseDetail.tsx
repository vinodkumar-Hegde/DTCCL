
import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, FileText, Activity, FlaskConical, Image as ImageIcon, GitBranch, MessageSquare, Play, ChevronRight, AlertCircle, Info, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ClinicalCase, HistoryData, LabReport, ImagingData, FlowchartNode } from '../types';
import { chatWithCase } from '../services/gemini';
import { supabase } from '../services/supabaseClient';

interface CaseDetailProps {
  caseId: number;
  onBack: () => void;
}

const CaseDetail: React.FC<CaseDetailProps> = ({ caseId, onBack }) => {
  const [caseData, setCaseData] = useState<ClinicalCase | null>(null);
  const [activeTab, setActiveTab] = useState<'history' | 'labs' | 'imaging' | 'notes' | 'flowchart' | 'summary'>('summary');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function fetchCase() {
      const { data, error } = await supabase
        .from('cases')
        .select('*')
        .eq('id', caseId)
        .single();
      if (!error) setCaseData(data || null);
    }
    fetchCase();
  }, [caseId]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  if (!caseData) return <div className="p-20 text-center">Loading case details...</div>;

  const history: HistoryData = JSON.parse(caseData.history || '{}');
  const labs: LabReport[] = JSON.parse(caseData.lab_reports || '[]');
  const imaging: ImagingData[] = JSON.parse(caseData.imaging || '[]');
  const flowchart: FlowchartNode[] = JSON.parse(caseData.flowchart_data || '[]');
  
  let notes: { day: string, note: string }[] = [];
  try {
    notes = JSON.parse(caseData.clinical_notes || '[]');
    if (!Array.isArray(notes)) {
      // Fallback for old string format
      notes = (caseData.clinical_notes || '').split(/(?=Day \d+:)/).map(dayNote => {
        const [dayTitle, ...contentParts] = dayNote.split(':');
        const content = contentParts.join(':').trim();
        return { day: dayTitle || 'Note', note: content || dayNote };
      }).filter(n => n.note);
    }
  } catch (e) {
    notes = [];
  }

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;
    const userMsg = userInput;
    setUserInput('');
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const aiResponse = await chatWithCase(caseData, userMsg, chatMessages);
      setChatMessages(prev => [...prev, { role: 'ai', text: aiResponse || "I'm sorry, I couldn't process that." }]);
    } catch (error) {
      setChatMessages(prev => [...prev, { role: 'ai', text: "Error connecting to AI assistant." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="sticky top-0 z-40 bg-slate-50/80 backdrop-blur-md py-4 -mx-4 px-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200">
        <button onClick={onBack} className="flex items-center text-slate-500 hover:text-blue-600 transition-colors font-bold">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to List
        </button>
        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
          <span>Medicine</span> <ChevronRight className="w-3 h-3" />
          <span>Cardiology</span> <ChevronRight className="w-3 h-3" />
          <span className="text-blue-600">Case #{caseId}</span>
        </div>
      </div>

      <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">{caseData.title}</h2>
        <div className="flex flex-wrap gap-4">
          <span className="px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-xs font-bold flex items-center gap-2">
            <Activity className="w-4 h-4" /> AI Analyzed
          </span>
          <span className="px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-bold flex items-center gap-2">
            <FlaskConical className="w-4 h-4" /> AIIMS Guidelines
          </span>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex overflow-x-auto pb-2 gap-2 scrollbar-hide">
        {[
          { id: 'summary', label: 'Quick Summary', icon: <Info className="w-4 h-4" /> },
          { id: 'history', label: 'History', icon: <FileText className="w-4 h-4" /> },
          { id: 'labs', label: 'Lab Reports', icon: <FlaskConical className="w-4 h-4" /> },
          { id: 'imaging', label: 'Imaging', icon: <ImageIcon className="w-4 h-4" /> },
          { id: 'notes', label: 'Clinical Notes', icon: <Activity className="w-4 h-4" /> },
          { id: 'flowchart', label: 'Flowchart', icon: <GitBranch className="w-4 h-4" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm whitespace-nowrap transition-all ${
              activeTab === tab.id 
                ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/20' 
                : 'bg-white border border-slate-100 text-slate-500 hover:border-blue-200'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="min-h-[400px]">
        <AnimatePresence mode="wait">
          {activeTab === 'summary' && (
            <motion.div key="summary" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                  <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <Info className="text-blue-600" /> Case Overview
                  </h3>
                  <p className="text-slate-600 leading-relaxed">{caseData.summary}</p>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-3xl p-8 shadow-sm">
                  <h3 className="text-xl font-bold text-blue-900 mb-4 flex items-center gap-2">
                    <MessageSquare className="text-blue-600" /> AI Opinion
                  </h3>
                  <p className="text-blue-800 leading-relaxed italic">"{caseData.ai_opinion}"</p>
                  <div className="mt-4 p-4 bg-white/50 rounded-xl border border-blue-200 text-xs text-blue-700">
                    <strong>Note:</strong> This opinion is generated based on standard AIIMS protocols and clinical best practices.
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div key="history" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Chief Complaints</h3>
                <ul className="space-y-2">
                  {history.chief_complaints?.map((c, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-600">
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" /> {c}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-4">History of Present Illness</h3>
                <p className="text-slate-600 leading-relaxed">{history.history_of_present_illness}</p>
              </div>
              <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Past & Family History</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Past History</h4>
                    <p className="text-slate-600">{history.past_history}</p>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Family History</h4>
                    <p className="text-slate-600">{history.family_history}</p>
                  </div>
                </div>
              </div>
              <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Personal History</h3>
                <p className="text-slate-600 leading-relaxed">{history.personal_history}</p>
              </div>
            </motion.div>
          )}

          {activeTab === 'labs' && (
            <motion.div key="labs" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Parameter</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Value</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Unit</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Reference Range</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {labs.map((lab, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-semibold text-slate-700">{lab.parameter}</td>
                      <td className={`px-6 py-4 font-bold ${lab.status === 'abnormal' ? 'text-red-600' : 'text-slate-900'}`}>{lab.value}</td>
                      <td className="px-6 py-4 text-slate-500">{lab.unit}</td>
                      <td className="px-6 py-4 text-slate-500 italic">{lab.reference}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${
                          lab.status === 'abnormal' ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600'
                        }`}>
                          {lab.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </motion.div>
          )}

          {activeTab === 'imaging' && (
            <motion.div key="imaging" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {imaging.length > 0 ? imaging.map((img, i) => (
                <div key={i} className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm group">
                  <div className="aspect-video bg-slate-100 relative overflow-hidden flex items-center justify-center">
                    <img src={img.url} alt={img.type} className="max-w-full max-h-full object-contain group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                    <div className="absolute top-4 left-4 px-3 py-1 bg-black/50 backdrop-blur-md text-white text-[10px] font-bold uppercase rounded-full">
                      {img.type}
                    </div>
                  </div>
                  <div className="p-6">
                    <h4 className="font-bold text-slate-800 mb-2">Findings</h4>
                    <p className="text-slate-600 text-sm leading-relaxed">{img.findings}</p>
                  </div>
                </div>
              )) : (
                <div className="md:col-span-2 py-20 text-center bg-white border border-slate-100 rounded-3xl">
                  <ImageIcon className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                  <p className="text-slate-400 font-medium">No imaging data available for this case.</p>
                </div>
              )}
              {caseData.video_url && (
                <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm md:col-span-2">
                  <div className="aspect-video bg-slate-900 flex items-center justify-center relative">
                    <video className="w-full h-full" controls muted>
                      <source src={caseData.video_url} type="video/mp4" />
                    </video>
                    <div className="absolute top-4 left-4 px-3 py-1 bg-red-600 text-white text-[10px] font-bold uppercase rounded-full flex items-center gap-1">
                      <Play className="w-3 h-3 fill-current" /> Procedure Video
                    </div>
                    <div className="absolute bottom-4 right-4 px-3 py-1 bg-black/50 backdrop-blur-md text-white text-[10px] font-bold uppercase rounded-full">
                      Patient Identity Masked
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}


          {activeTab === 'notes' && (
            <motion.div key="notes" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-12">
              <div className="relative">
                <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-slate-100 hidden sm:block" />
                <div className="space-y-12">
                  {notes.map((note, i) => (
                    <div key={i} className="relative flex flex-col sm:flex-row gap-8 group">
                      {/* Timeline Marker */}
                      <div className="hidden sm:flex absolute left-6 -translate-x-1/2 w-4 h-4 rounded-full bg-blue-600 border-4 border-white shadow-sm z-10 group-hover:scale-150 transition-transform" />
                      
                      {/* Day Card */}
                      <div className="sm:ml-16 flex-1 bg-white border border-slate-200 rounded-[2rem] p-8 shadow-sm hover:shadow-md transition-all border-l-8 border-l-blue-900">
                        <div className="flex items-center justify-between mb-6">
                          <div className="px-4 py-1.5 bg-blue-900 text-white rounded-xl font-bold text-sm shadow-lg shadow-blue-900/20">
                            {note.day}
                          </div>
                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                            <Activity className="w-3 h-3" /> Clinical Progress
                          </div>
                        </div>
                        <div className="prose prose-slate max-w-none">
                          <p className="text-slate-700 leading-relaxed text-lg font-medium">
                            {note.note}
                          </p>
                        </div>
                        <div className="mt-6 pt-6 border-t border-slate-50 flex gap-4">
                          <div className="flex items-center gap-2 text-xs text-slate-400">
                            <div className="w-2 h-2 bg-emerald-500 rounded-full" /> Vitals Stable
                          </div>
                          <div className="flex items-center gap-2 text-xs text-slate-400">
                            <div className="w-2 h-2 bg-blue-500 rounded-full" /> Treatment Active
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
          {activeTab === 'flowchart' && (
            <motion.div key="flowchart" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-white border border-slate-200 rounded-3xl p-12 shadow-sm min-h-[500px] flex flex-col items-center">
                <div className="w-full max-w-md space-y-8 relative">
                  {flowchart.length > 0 ? flowchart.map((node, i) => (
                    <div key={node.id} className="relative flex flex-col items-center">
                      <div className={`w-full p-6 rounded-2xl border-2 text-center font-bold shadow-sm transition-all hover:scale-105 ${
                        node.type === 'decision' ? 'bg-amber-50 border-amber-200 text-amber-800 rounded-3xl rotate-1' :
                        node.type === 'outcome' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' :
                        'bg-blue-50 border-blue-200 text-blue-800'
                      }`}>
                        {node.label}
                      </div>
                      {i < flowchart.length - 1 && (
                        <div className="h-10 w-0.5 bg-slate-200 my-2 relative">
                          <ChevronRight className="absolute bottom-0 -left-[7px] rotate-90 text-slate-300 w-4 h-4" />
                        </div>
                      )}
                    </div>
                  )) : (
                    <div className="py-20 text-center">
                      <GitBranch className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                      <p className="text-slate-400 font-medium">No flowchart data available.</p>
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-6">
                <div className="bg-slate-900 text-white rounded-3xl p-8 shadow-xl border border-slate-700">
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Info className="text-blue-400 w-5 h-5" /> Quick Summary
                  </h3>
                  <p className="text-slate-300 leading-relaxed text-sm">{caseData.summary}</p>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-3xl p-8">
                  <h4 className="text-blue-900 font-bold mb-2 flex items-center gap-2">
                    <Activity className="w-4 h-4" /> Case Outcome
                  </h4>
                  <p className="text-blue-800 text-sm italic">
                    {flowchart[flowchart.length - 1]?.label || 'Pending final assessment.'}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Comparison Section */}
      {caseData.comparison_case_id && (
        <section className="mt-20 space-y-8">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-slate-800">Case Comparison</h3>
              <p className="text-slate-500">Compare this case with a similar presentation showing variation in treatment.</p>
            </div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm border-l-4 border-l-blue-600">
              <h4 className="text-xs font-bold text-blue-600 uppercase mb-2">Current Case</h4>
              <h5 className="text-lg font-bold mb-4">{caseData.title}</h5>
              <div className="space-y-4 text-sm">
                <div className="flex justify-between border-b border-slate-50 pb-2">
                  <span className="text-slate-400">Treatment</span>
                  <span className="font-bold text-slate-700">Standard Protocol</span>
                </div>
                <div className="flex justify-between border-b border-slate-50 pb-2">
                  <span className="text-slate-400">Recovery</span>
                  <span className="font-bold text-slate-700">14 Days</span>
                </div>
              </div>
            </div>
            <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm border-l-4 border-l-amber-600">
              <h4 className="text-xs font-bold text-amber-600 uppercase mb-2">Comparison Case</h4>
              <h5 className="text-lg font-bold mb-4">Atypical Presentation of {caseData.title}</h5>
              <div className="space-y-4 text-sm">
                <div className="flex justify-between border-b border-slate-50 pb-2">
                  <span className="text-slate-400">Treatment</span>
                  <span className="font-bold text-slate-700">Aggressive Intervention</span>
                </div>
                <div className="flex justify-between border-b border-slate-50 pb-2">
                  <span className="text-slate-400">Recovery</span>
                  <span className="font-bold text-slate-700">45 Days</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Floating Chatbot */}
      <div className="fixed bottom-8 right-8 z-50">
        <AnimatePresence>
          {isChatOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="absolute bottom-20 right-0 w-[400px] h-[500px] bg-white border border-slate-200 rounded-3xl shadow-2xl flex flex-col overflow-hidden"
            >
              <div className="bg-blue-900 p-4 text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold">Case Assistant</h4>
                    <p className="text-[10px] text-blue-200">AI-Powered Analysis</p>
                  </div>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
                {chatMessages.length === 0 && (
                  <div className="text-center py-10 space-y-4">
                    <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto">
                      <Info className="w-6 h-6" />
                    </div>
                    <p className="text-sm text-slate-500 px-8">Ask me anything about this case. I can analyze lab reports, history, and treatment plans.</p>
                  </div>
                )}
                {chatMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                      msg.role === 'user' 
                        ? 'bg-blue-600 text-white rounded-tr-none' 
                        : 'bg-white border border-slate-100 text-slate-700 rounded-tl-none shadow-sm'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-white border border-slate-100 p-3 rounded-2xl rounded-tl-none shadow-sm flex gap-1">
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" />
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              <div className="p-4 bg-white border-t border-slate-100 flex gap-2">
                <input 
                  type="text" 
                  placeholder="Type your question..."
                  className="flex-1 bg-slate-100 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <button 
                  onClick={handleSendMessage}
                  className="w-10 h-10 bg-blue-900 text-white rounded-xl flex items-center justify-center hover:bg-blue-800 transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <button 
          onClick={() => setIsChatOpen(!isChatOpen)}
          className={`w-14 h-14 rounded-full shadow-2xl flex items-center justify-center transition-all ${
            isChatOpen ? 'bg-slate-800 text-white rotate-90' : 'bg-blue-900 text-white hover:scale-110'
          }`}
        >
          {isChatOpen ? <ArrowLeft className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
        </button>
      </div>
    </div>
  );
};

export default CaseDetail;
