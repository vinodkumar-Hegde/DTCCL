import React, { useState, useEffect } from 'react';
import { Search, ChevronRight, BookOpen, Activity, Heart, Brain, Baby, Scissors, FlaskConical, FileText } from 'lucide-react';
import { motion } from 'motion/react';
import { Subject, ClinicalCase, Disease } from '../types';

interface Speciality {
  id: number;
  name: string;
  subject_id: number;
}
import { supabase } from '../services/supabaseClient';

interface LandingProps {
  onSelectSubject: (subject: Subject) => void;
  onSelectCase: (id: number) => void;
  onSelectSpeciality: (subject: Subject, speciality: Speciality) => void;
}

const Landing: React.FC<LandingProps> = ({ onSelectSubject, onSelectCase, onSelectSpeciality }) => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [specialities, setSpecialities] = useState<Speciality[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [cases, setCases] = useState<ClinicalCase[]>([]);
  const [diseases, setDiseases] = useState<Disease[]>([]);


  useEffect(() => {
    async function fetchSubjectsSpecialitiesDiseasesCases() {
      const [
        { data: subjectsData, error: subjectsError },
        { data: specialitiesData, error: specialitiesError },
        { data: diseasesData, error: diseasesError },
        { data: casesData, error: casesError }
      ] = await Promise.all([
        supabase.from('subjects').select('*'),
        supabase.from('specialities').select('*'),
        supabase.from('diseases').select('*'),
        supabase.from('cases').select('*'),
      ]);
      if (subjectsError) {
        console.error('Error fetching subjects:', subjectsError);
      } else {
        setSubjects(subjectsData || []);
      }
      if (specialitiesError) {
        console.error('Error fetching specialities:', specialitiesError);
      } else {
        setSpecialities(specialitiesData || []);
      }
      if (diseasesError) {
        console.error('Error fetching diseases:', diseasesError);
      } else {
        setDiseases(diseasesData || []);
      }
      if (casesError) {
        console.error('Error fetching cases:', casesError);
      } else {
        setCases(casesData || []);
      }
    }
    fetchSubjectsSpecialitiesDiseasesCases();
  }, []);

  const getSubjectIcon = (name: string) => {
    switch (name.toLowerCase()) {
      case 'medicine': return <Heart className="w-6 h-6" />;
      case 'surgery': return <Scissors className="w-6 h-6" />;
      case 'pediatrics': return <Baby className="w-6 h-6" />;
      case 'ent': return <Activity className="w-6 h-6" />;
      case 'obg': return <FlaskConical className="w-6 h-6" />;
      default: return <BookOpen className="w-6 h-6" />;
    }
  };

  const getSubjectImage = (name: string) => {
    // Using high-quality 3D icons from Icons8 Fluency set
    switch (name.toLowerCase()) {
      case 'medicine': return 'https://img.icons8.com/3d-fluency/300/stethoscope.png';
      case 'surgery': return 'https://img.icons8.com/3d-fluency/300/scalpel.png';
      case 'pediatrics': return 'https://img.icons8.com/3d-fluency/300/baby.png';
      case 'ent': return 'https://img.icons8.com/3d-fluency/300/ear.png';
      case 'obg': return 'https://img.icons8.com/3d-fluency/300/pregnant.png';
      default: return 'https://img.icons8.com/3d-fluency/300/medical-history.png';
    }
  };

  const filteredCases = searchQuery.trim().length > 0
    ? cases.filter(c =>
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.summary.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : cases;

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="text-center space-y-6 py-12">
        <motion.h2 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-4xl md:text-6xl font-bold text-blue-900 tracking-tight"
        >
          DocTutorials CCB
        </motion.h2>
        <p className="text-slate-500 max-w-2xl mx-auto text-lg">
          Explore a vast repository of real-world clinical cases, analyzed and structured with AI to enhance your medical learning journey.
        </p>

        {/* Search Engine */}
        <div className="relative max-w-3xl mx-auto mt-12">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur opacity-25 group-focus-within:opacity-50 transition duration-1000 group-focus-within:duration-200"></div>
            <div className="relative flex items-center bg-white border border-slate-200 rounded-2xl shadow-2xl shadow-blue-900/10">
              <Search className="ml-6 text-slate-400 w-6 h-6" />
              <input 
                type="text" 
                placeholder="Search for cases, diseases, or symptoms..."
                className="w-full pl-4 pr-6 py-5 bg-transparent rounded-2xl focus:outline-none text-lg text-slate-700 placeholder:text-slate-400"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <div className="mr-4 hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                <kbd className="font-sans">CMD</kbd>
                <span>+</span>
                <kbd className="font-sans">K</kbd>
              </div>
            </div>
            {searchQuery.trim().length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-4 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 overflow-hidden divide-y divide-slate-50">
                {filteredCases.length > 0 ? (
                  filteredCases.slice(0, 8).map(c => (
                    <button 
                      key={c.id}
                      onClick={() => setSearchQuery(c.title)}
                      className="w-full px-6 py-4 text-left hover:bg-blue-50/50 flex items-center justify-between group transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                          <FileText className="w-5 h-5" />
                        </div>
                        <div>
                          <span className="text-slate-700 font-bold block">{c.title}</span>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider">Case Study</span>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
                    </button>
                  ))
                ) : (
                  <div className="px-6 py-8 text-center text-slate-500">
                    <p>No cases found matching "{searchQuery}"</p>
                  </div>
                )}
              </div>
            )}
          </div>
          
        </div>
      </section>

      {/* Cases by Subject & Speciality */}
      <section className="space-y-8 mt-12">
        <h3 className="text-2xl font-bold text-slate-800">Cases by Subject</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCases.length === 0 ? (
            <div className="text-slate-400">No cases found.</div>
          ) : (
            filteredCases.map(c => (
              <div key={c.id} className="w-64 rounded-lg border border-slate-200 bg-white shadow p-4 flex flex-col gap-2">
                <h6 className="text-md font-bold text-blue-900 mb-1">{c.title}</h6>
                <p className="text-slate-600 text-xs line-clamp-2">{c.summary}</p>
                <button className="mt-auto px-3 py-1 bg-blue-600 text-white rounded font-semibold hover:bg-blue-700 transition-colors" onClick={() => onSelectCase(c.id)}>
                  View Case
                </button>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
};

export default Landing;
